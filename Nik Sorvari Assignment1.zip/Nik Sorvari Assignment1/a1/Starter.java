//Author: Nik Sorvari
//CSC155
//Assignment 1
//9-22-2016
package a1;


public class Starter 
{	

   public static void main(String[] args) { new A1(); }

}